"""
generate_data.py
================
Reads the solar/household Excel file and writes data_lookup.js,
which is loaded by map.html to colour the hex map.

USAGE
-----
  python generate_data.py                          # uses defaults below
  python generate_data.py my_new_data.xlsx         # custom input file
  python generate_data.py input.xlsx output.js     # custom input + output

REQUIREMENTS
------------
  pip install pandas openpyxl numpy

EXPECTED EXCEL SHEETS
---------------------
  Sheet1   Solar installs per postcode (wide format)
           Columns: "Small Unit Installation Postcode", 2011, 2012, ..., 2026, "SA2 name"

  Sheet2   Households per SA2 (wide format)
           Columns: "SA2 Name", "Households 2021 - ABS Number",
                    "Projected 2022 - Households", "Projected 2023 - Households",
                    "Projected 2024 - Households"

  Sheet3   Postcode → SA2 mapping
           Columns: "postcode", "sa2_name"

  Sheet4   Battery installs per postcode per month (wide format)
           Columns: "Small unit postcode", <datetime columns>, "SA2 name"

ADDING NEW YEARS
----------------
  1. Add the new year column to Sheet1 (solar installs).
  2. Add the new household projection column to Sheet2.
  3. Update INSTALL_YEARS and HOUSEHOLD_COLS below to include the new year.
  4. Re-run this script.

ADDING NEW BATTERY MONTHS
--------------------------
  Sheet4 columns are auto-detected as datetime columns — just add the new
  month column to Sheet4 and re-run. No code changes needed.
"""

import sys
import json
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime

# ══════════════════════════════════════════════════════════════════════════
# CONFIGURATION — update these when your data grows
# ══════════════════════════════════════════════════════════════════════════

INPUT_FILE  = "household_postcode_data.xlsx"
OUTPUT_FILE = "data_lookup.js"

# Years present in Sheet1 solar installs AND for which we have households.
# Add new years here as they become available.
INSTALL_YEARS = [2021, 2022, 2023, 2024]

# Matching household columns in Sheet2 for each year above.
# Key = year int, Value = exact column name in Sheet2.
HOUSEHOLD_COLS = {
    2021: "Households 2021 - ABS Number",
    2022: "Projected 2022 - Households",
    2023: "Projected 2023 - Households",
    2024: "Projected 2024 - Households",
}

# Sheet names
SHEET_SOLAR     = "Sheet1"
SHEET_HOUSEHOLDS = "Sheet2"
SHEET_MAPPING   = "Sheet3"
SHEET_BATTERY   = "Sheet4"

# Solar year dropdown in the map UI (independent of IPH years)
SOLAR_YEARS = list(range(2011, 2027))

# ══════════════════════════════════════════════════════════════════════════


def load_data(filepath: str):
    print(f"Reading {filepath} ...")

    # ── Solar installs (Sheet1) ────────────────────────────────────────────
    df_solar = pd.read_excel(filepath, sheet_name=SHEET_SOLAR)
    df_solar["SA2 name"] = df_solar["SA2 name"].str.strip()
    solar_by_sa2 = df_solar.groupby("SA2 name")[INSTALL_YEARS].sum()
    print(f"  Solar: {len(solar_by_sa2)} SA2s, years {INSTALL_YEARS}")

    # ── Households (Sheet2) ───────────────────────────────────────────────
    df_hh = pd.read_excel(filepath, sheet_name=SHEET_HOUSEHOLDS)
    df_hh["SA2 Name"] = df_hh["SA2 Name"].str.strip()
    hh_rename = {"SA2 Name": "sa2_name"}
    hh_rename.update({v: k for k, v in HOUSEHOLD_COLS.items()})
    needed = ["SA2 Name"] + list(HOUSEHOLD_COLS.values())
    hh = df_hh[needed].copy().rename(columns=hh_rename)
    hh = hh.dropna(subset=["sa2_name"]).set_index("sa2_name")
    print(f"  Households: {len(hh)} SA2s")

    # ── Postcode mapping (Sheet3) ─────────────────────────────────────────
    df_map = pd.read_excel(filepath, sheet_name=SHEET_MAPPING)
    df_map["sa2_name"] = df_map["sa2_name"].str.strip()
    pc_by_sa2 = (
        df_map.groupby("sa2_name")["postcode"]
        .apply(lambda x: ", ".join(str(int(p)) for p in sorted(x)))
        .to_dict()
    )
    print(f"  Postcode map: {len(pc_by_sa2)} SA2s")

    # ── Battery monthly (Sheet4) ──────────────────────────────────────────
    df_bat = pd.read_excel(filepath, sheet_name=SHEET_BATTERY)
    df_bat["SA2 name"] = df_bat["SA2 name"].str.strip()
    month_cols = [c for c in df_bat.columns if isinstance(c, datetime)]
    bat_by_sa2 = df_bat.groupby("SA2 name")[month_cols].sum()
    print(f"  Battery: {len(bat_by_sa2)} SA2s, {len(month_cols)} months")

    return solar_by_sa2, hh, pc_by_sa2, bat_by_sa2, month_cols


def compute_iph(solar_by_sa2, hh, pc_by_sa2):
    merged = solar_by_sa2.join(hh, how="inner", lsuffix="_solar", rsuffix="_hh")
    print(f"  Matched SA2s (solar ∩ households): {len(merged)}")

    records = {}
    for yr in INSTALL_YEARS:
        solar_col = f"{yr}_solar" if f"{yr}_solar" in merged.columns else yr
        hh_col    = f"{yr}_hh"    if f"{yr}_hh"    in merged.columns else yr
        ratio = (merged[solar_col] / merged[hh_col].replace(0, float("nan"))).fillna(0)
        for sa2, val in ratio.items():
            if sa2 not in records:
                records[sa2] = {"postcodes": pc_by_sa2.get(sa2, "")}
            records[sa2][str(yr)] = round(float(val), 6)

    max_vals = [max(v[str(y)] for y in INSTALL_YEARS) for v in records.values()]
    p95 = round(float(np.percentile(max_vals, 95)), 6)
    print(f"  IPH P95 (colour scale cap): {p95}")
    return records, p95


def compute_battery(bat_by_sa2, month_cols, pc_by_sa2):
    records = {}
    bat_months = {}  # key -> label for MAP_CONFIG
    for col in month_cols:
        key = col.strftime("%Y-%m")
        bat_months[key] = col.strftime("%b %Y")

    for sa2, row in bat_by_sa2.iterrows():
        monthly = {}
        for col in month_cols:
            monthly[col.strftime("%Y-%m")] = int(row[col]) if pd.notna(row[col]) else 0
        records[sa2] = {"postcodes": pc_by_sa2.get(sa2, ""), **monthly}

    return records, bat_months


def write_js(output_file, iph_records, bat_records, bat_months, p95):
    str_years = [str(y) for y in INSTALL_YEARS]
    default_iph_year = str_years[-1]
    default_bat_month = list(bat_months.keys())[-1]

    lines = [
        "// AUTO-GENERATED by generate_data.py",
        f"// Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        "// Do not edit by hand — re-run generate_data.py when your Excel file changes.",
        "",
        "window.MAP_CONFIG = {",
        f"  iphYears: {json.dumps(str_years)},",
        f"  defaultIphYear: {json.dumps(default_iph_year)},",
        "  batteryMonths: {",
    ]
    for k, v in bat_months.items():
        lines.append(f'    {json.dumps(k)}: {json.dumps(v)},')
    lines += [
        "  },",
        f"  defaultBatMonth: {json.dumps(default_bat_month)},",
        f"  solarYears: {json.dumps([str(y) for y in SOLAR_YEARS])},",
        f"  defaultSolarYear: {json.dumps(str(SOLAR_YEARS[-1]))},",
        f"  iphP95: {p95},",
        "};",
        "",
        "// IPH_DATA: { [sa2_name]: { '2021': ratio, ..., postcodes: '...' } }",
        "// ratio = solar installs in SA2 / households in SA2, for that year.",
        "// Values above 1.0 are possible in commercial/industrial SA2s.",
        "window.IPH_DATA = {",
    ]
    for sa2, rec in iph_records.items():
        sa2_esc = sa2.replace('"', '\\"')
        year_pairs = ", ".join(f'"{y}": {rec[y]}' for y in str_years if y in rec)
        pcs = rec.get("postcodes", "").replace('"', "")
        lines.append(f'  "{sa2_esc}": {{{year_pairs}, "postcodes": "{pcs}"}},')
    lines += [
        "};",
        "",
        "// BATTERY_DATA: { [sa2_name]: { 'YYYY-MM': count, ..., postcodes: '...' } }",
        "window.BATTERY_DATA = {",
    ]
    for sa2, rec in bat_records.items():
        sa2_esc = sa2.replace('"', '\\"')
        month_pairs = ", ".join(
            f'"{k}": {v}' for k, v in rec.items() if k != "postcodes"
        )
        pcs = rec.get("postcodes", "").replace('"', "")
        lines.append(f'  "{sa2_esc}": {{{month_pairs}, "postcodes": "{pcs}"}},')
    lines.append("};")

    output = "\n".join(lines)
    Path(output_file).write_text(output, encoding="utf-8")
    print(f"\nWrote {output_file}  ({len(output):,} bytes, {len(lines)} lines)")


def main():
    args = sys.argv[1:]
    input_file  = args[0] if len(args) >= 1 else INPUT_FILE
    output_file = args[1] if len(args) >= 2 else OUTPUT_FILE

    solar, hh, pc_map, bat, month_cols = load_data(input_file)

    print("\nComputing IPH ratios ...")
    iph_records, p95 = compute_iph(solar, hh, pc_map)

    print("Computing battery records ...")
    bat_records, bat_months = compute_battery(bat, month_cols, pc_map)

    print(f"\nWriting {output_file} ...")
    write_js(output_file, iph_records, bat_records, bat_months, p95)

    print("\nDone. Copy data_lookup.js next to map.html and refresh the browser.")


if __name__ == "__main__":
    main()
